module.exports = require('./win32_arm64/koffi.node');
