# @koromix/koffi-darwin-x64

This contains the darwin-x64 binaries for [Koffi](https://koffi.dev), a fast and and easy-to-use dynamic C FFI (foreign function interface) module for Node.js.

> [!NOTE]
> Do not install this package directly, use `npm install koffi` instead.
